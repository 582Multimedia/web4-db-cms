<?php
//This will show errors in the browser if there are some
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

//First load the DB connection
require_once("db_connect.php");


?>
